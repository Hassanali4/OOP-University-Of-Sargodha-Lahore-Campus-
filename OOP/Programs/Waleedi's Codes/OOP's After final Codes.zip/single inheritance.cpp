#include<iostream>
using namespace std;
class A{
	private:
		
		public:
			void display(){
				cout<<"i am a student ";
			}
		};
		class B:public A{
			public:
				void show(){
					cout<<"of BSCS ";
					cout<<"in  university of sargodha lahore campus";
				}
		};
		int main(){
			B shah;
			
			shah.display();
			shah.show();
		}
	
