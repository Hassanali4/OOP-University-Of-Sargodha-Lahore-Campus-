#include<conio.h>
#include<iostream>
using namespace std;
class CC{
protected:
int a,b;
};
class ABC:public CC{
public:
void input(){
cout<<"Enter 1st Number: ";
cin>>a;
cout<<"Enter 2nd Number: ";
cin>>b;
}
};
class CPC:public ABC{
public:
void show(){
cout<<"Sum of both Numbers is "<<a+b;
}
};
int main(){
CPC a1;
a1.input();
a1.show();
getch();
}
