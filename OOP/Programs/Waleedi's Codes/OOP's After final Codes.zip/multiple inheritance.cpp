#include<iostream>
using namespace std;
class A{
	private:
		
		public:
			void display(){
				cout<<"i am a student ";
			}
		};
		class B{
			public:
				void show(){
					cout<<"of BSCS ";
					
				}
		};
		class C: public A , public B{
			public:
				void print(){
					cout<<"2nd smester";
					cout<<"in  university of sargodha lahore campus";
				}
		};
		int main(){
			C o1;
			
			o1.display();
			o1.show();
			o1.print();
		}
	
