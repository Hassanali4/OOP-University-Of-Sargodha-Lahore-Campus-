#include<iostream>
using namespace std;
class Base{
protected:
int a;
public:
Base(){a=10;}};
class Derived:public Base{
int b;
public:
Derived(){b=20;}
void show(){
cout<<a<<endl<<b<<endl;}};
int main(){Derived a1;a1.show();system("pause>0");}
