#include<iostream>
#include<conio.h>
using namespace std;
class grand{
public:
void show(int a){
cout<<a<<endl;
}
};
class parent:public grand{
public:
void show(int a,int b){
grand::show(a);
cout<<b<<endl;
}
};
class child:public parent{
public:
void show(int a,int b,int c){
parent::show(a,b);
cout<<c;
}
};
int main(){
child ob1;
ob1.show(10,20,30);
getch();
}
