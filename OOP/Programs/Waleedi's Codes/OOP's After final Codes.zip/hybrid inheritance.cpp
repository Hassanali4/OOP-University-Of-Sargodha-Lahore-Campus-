#include<iostream>
using namespace std;
class A{
	private:
		
		public:
			void display(){
				cout<<"i am a student ";
			}
		};
		class B:public A{
			public:
				void show(){
					cout<<"of BSCS ";
					
				}
		};
		class C: public A{
			public:
				void print(){
					cout<<"2nd smester";
					cout<<"in  university of sargodha lahore campus"<<endl;
				}
		};
	class D:public B , public C{
			public:
				void out(){
					cout<<"shah";
				}
		};
		int main(){
			D aa;
			
			
			aa.show();
			aa.print();
			aa.out();
		}
	
